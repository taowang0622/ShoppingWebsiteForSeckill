CREATE PROCEDURE execute_seckill(IN v_seckill_id BIGINT, IN v_phone BIGINT, IN v_kill_time TIMESTAMP, OUT r_result INT)
  BEGIN
    DECLARE insert_count INT DEFAULT 0;
    START TRANSACTION; -- start a transaction
    INSERT IGNORE INTO success_killed
    (product_id, user_phone, create_time)
    VALUES (v_seckill_id, v_phone, v_kill_time);
    SELECT row_count()
    INTO insert_count; -- row_count() return the number of affected rows by the previous delete/insert/update statement
    IF (insert_count = 0)
    THEN
      ROLLBACK;
      SET r_result = -1; -- repeated seckill
    ELSEIF (insert_count < 0)
      THEN
        ROLLBACK;
        SET r_result = -2; -- internal server error
    ELSE
      UPDATE products
      SET product_num = product_num - 1
      WHERE id = v_seckill_id
            AND end_time > v_kill_time
            AND start_time < v_kill_time
            AND product_num > 0;
      SELECT row_count()
      INTO insert_count;
      IF (insert_count = 0)
      THEN
        ROLLBACK;
        SET r_result = 0;     -- seckill expired!!
      ELSEIF (insert_count < 0)
        THEN
          ROLLBACK;
          SET r_result = -2;   -- internal server error
      ELSE
        COMMIT;
        SET r_result = 1;  -- seckill successful!!!
      END IF;
    END IF;
  END;
